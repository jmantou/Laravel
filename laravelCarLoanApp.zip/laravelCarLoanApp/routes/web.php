<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', 'WelcomeController@home');
Route::get('/contact', 'ContactController@home');

// Resource Router for multiple RESTful actions
Route::resource('loan', 'LoanController');

// Contact Form Rout & Validation
// TODO To be implemented later in controller
Route::post('contact', function()
{
    $data = Input::all();
    $validationRules = array('subject' => 'required', 
                             'message' => 'required',
                             'email' => 'required',
                             'name' => 'required');

    $validator = Validator::make($data, $validationRules);
    if($validator->fails()) 
    {
        return Redirect::to('contact')->withErrors($validator)->withInput();
    }

    return 'Your message has been sent';
 });


