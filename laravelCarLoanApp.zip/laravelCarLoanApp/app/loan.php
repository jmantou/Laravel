<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

// Hard Coded Monthly Loan rate 1% equals 12% per year
define('RATE', 0.010);

class Loan extends Model
{
    protected $fillable = ['name', 'surname', 'carmodel', 'price', 'nper', 'advance', 'pmt'];

    public function getPmtAttribute()
    {
    	
    	return round((($this->price - $this->advance)  * RATE) / (1 - 1 / pow((1 +RATE), $this->nper)), 2);
    }

    protected $appends = ['pmt'];
}
