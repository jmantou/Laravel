<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Contact Form</title>
  <style>
    .error {
      color: #FF0000;
    }
  </style>
</head>
<body>
  
 
@extends('layout')
@section('content')
<h1>
  Basket Super Stats Calculator - Basketball Game Advance Stats for Every Player
</h1>
<p>
  <h3>If you like to Contact us please fill the form below:</h3>
 
      <span class="error">* required field</span>
  </p>
  <form class="form-horizontal" action="">
      <div class="form-group">
        <label class="control-label col-sm-2" for="name">Name:</label>
        <div class="col-sm-10">
          <input type="text" class="form-control" id="name">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="email">E-Mail:</label>
        <div class="col-sm-10">
          <input type="email" class="form-control" id="email">
        </div>
      </div>
      <div class="form-group">
        <label class="control-label col-sm-2" for="comment">Comments:</label>
        <div class="col-sm-10">
          <input type="textarea" class="form-control" id="comment">
        </div>
      </div>
      <div class="form-group"> 
        <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Submit</button>
        </div>
      </div>
    </form>
  </div>  
  <p>
  </p>
@stop
  </body>
</html>