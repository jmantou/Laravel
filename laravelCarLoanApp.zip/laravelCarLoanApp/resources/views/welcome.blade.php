<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Car Loan Calculator</title>
</head>
<body>
  
 
@extends('layout')
 
@section('content')
<div class="header-text">
 <h1>The Car Loan Calculator <br/> Compute your next car loan</h1>
  <p>
  Enter your name, favorite car to buy, the advance money and the car price to find the payment of your next car!
 </p>
  </div>
  <br/>
  <hr/>
  <section class="image">
      <img src = "/images/car-loan.jpg">
  </section>
  <hr/>
<div class="header-text">
 <p>
   <h1>To compute your loan press<a href="{{ route('loan.index') }}"> here</a></h1>
 </p>
  </div>
  
@stop
  </body>
</html>