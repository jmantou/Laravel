<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>The Car Loan Calculator</title>
  
	  <!-- Latest compiled and minified Bootstrap CSS -->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css"
    integrity="sha384-BVYiiSIFeK1dGmJRAkycuHAHRg32OmUcww7on3RYdg4Va+PmSTsz/K68vbdEjh4u" crossorigin="anonymous">
		<link rel="stylesheet" type="text/css" href="public/css/standard.css">
    <link rel="stylesheet" type="text/css" href="public/css/style.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
    <script src="//netdna.bootstrapcdn.com/bootstrap/3.0.3/js/bootstrap.min.js"></script>
  <style> 
    @import url(//fonts.googleapis.com/css?family=Lato:700);
  </style>
</head>
<body>
    <header>
	  <nav class="navbar navbar-default" role="navigation">
      <div class="navbar-header">
        <ul class="nav navbar-nav">
        <li><a href="./">Home</a></li>
        <li><a href="./about">About</a></li>
        <li><a href="./contact">Contact</a></li>
      </ul>
      </div>
    </nav> <!-- End of navbar navbar-default -->
  </header>
 @yield('content')
</body>
</html>