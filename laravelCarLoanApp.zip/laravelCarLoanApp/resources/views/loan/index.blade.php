<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Compute the Loan of your next car</title>
</head>
<body>
  
 
@extends('layout')
 
@section('content')
<div class="header-text">
 <h1>The Car Loan Calculator <br/> Computing and Comparing Car Loans</h1>
  <p>
    <h4>The Car Loan calculator is a simple Laravel App for computing and comparing Car Loans.</h4>
 </p>
  </div>
  <hr/>
  <div class="header-text">
    <div class="row">
      <div class="col-md-12">
    <br />
    <h2 align="center">Loan Data</h2>
    <h4 ALIGN="center">(12% Yearly Nominal Rate)</h4>
  <br />
    @if($message = Session::get('success'))
      <div class="alert alert-success">
      <p>{{ $message }}</p>
  </div>
    @endif
  <div align="right">
   <a href="{{ route('loan.create') }}" class="btn btn-primary">Add New Loan</a>
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Name</th>
    <th>Surname</th>
    <th>Car Model </th>
    <th>Car Price</th>
    <th>Number of Payments</th>
    <th>Advance</th>
    <th>Monthly Payment</th>
    <th></th>
   </tr>
   @foreach($loans as $row)
   <tr>
    <td>{{$row['name']}}</td>
    <td>{{$row['surname']}}</td>
    <td>{{$row['carmodel']}}</td>
    <td>{{$row['price']}}</td>
    <td>{{$row['nper']}}</td>
    <td>{{$row['advance']}}</td>
    <td>{{$row['pmt'] }} €</td>
    <td>
      <form method="post" class="delete_form" action="{{ action('LoanController@destroy', $row['id']) }}">
        {{ csrf_field() }}
        <input type="hidden" name="_method" value="Delete" />
        <button type="submit" class="btn btn-danger">Delete</button>
     </form>
    </td>
    <td>
      
    </td>
   </tr>
   @endforeach
  </table>
 </div>
</div>
<script>
  $(document).ready(function()
  {
    $(.'delete_form').on('submit', function()
    {
        if(confirm("Are you sure you want to delete the record?"))
        {
            return true;
        }
        else
        {
            return false;
        }
    });
  });
</script>
@endsection
  </body>
</html>