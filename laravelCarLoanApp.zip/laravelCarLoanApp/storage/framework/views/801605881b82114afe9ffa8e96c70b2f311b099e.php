<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Compute the Loan of your next car</title>
</head>
<body>
  
 

 
<?php $__env->startSection('content'); ?>
<div class="header-text">
 <h1>The Car Loan Calculator <br/> Computing and Comparing Car Loans</h1>
  <p>
    The Car Loan calculator is a simple Laravel App for computing and comparing Car Loans. You can also save your computations
    in the apps database.
 </p>
  </div>
  <br/>
  <hr/>
  <div class="header-text">
    <h2>Fill the form below to compute your Car Loan:</h2>
  </div>
  <hr/>
  
  <?php if(count ($errors) > 0): ?>
    <div class ="alert alert-danger">
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <li> <?php echo e($error); ?> </li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </ul>
    </div>  
  <?php endif; ?>

  <?php if(\Session::has('success')): ?>
    <div class ="alert alert-success">
      <p> <?php echo e(\Session::get('success')); ?> </p>
    </div>
  <?php endif; ?>
  <form class="form-inline" action="<?php echo e(url('loan')); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

    <p>
      
      <label class="mr-sm-2" for="name">Name:</label>
      <input type="text" class="form-control mb-2 mr-sm-2" name="name" id="name" placeholder="Enter name" required>
      <label class="mr-sm-2" for="surname">Surname:</label>
      <input type="text" class="form-control mb-2 mr-sm-2" name="surname" id="surname" placeholder="Enter Surname" required>
      <label class="mr-sm-2" for="league">Car Model:</label>
      <input type="text" class="form-control mb-2 mr-sm-2" name="carmodel" id="carmodel" placeholder="Enter Brand and Model" required>
    </p>
    <section class="jumbotron">
    <div class="form-inline>">
      <p>
        <label for="price" class="mr-sm-2">Price:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="price" id="price" placeholder="Enter Car Price" required> <br/>
        <label for="nper" class="mr-sm-2">Number of Monthly Payments:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="nper" id="nper" placeholder="Monthly Payments" required>
        <label for="advance" class="mr-sm-2">Advance:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="advance" id="advance" placeholder="Advance Money" required>
      </p>
    </div>
    </section>
    <p></p>
    
    <p></p>
     
    <section class="jumbotron"></section>
    <button type="submit" class="btn btn-primary mb-2">Submit</button>
    </section>
  </form>
<div class="header-text">
 <p>
   
 </p>
  </div>
  
<?php $__env->stopSection(); ?>
  </body>
</html>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>