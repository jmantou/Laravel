<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Compute the Loan of your next car</title>
</head>
<body>
  
 

 
<?php $__env->startSection('content'); ?>
<div class="header-text">
 <h1>The Car Loan Calculator <br/> Computing and Comparing Car Loans</h1>
  <p>
    <h4>The Car Loan calculator is a simple Laravel App for computing and comparing Car Loans.</h4>
 </p>
  </div>
  <hr/>
  <div class="header-text">
    <div class="row">
      <div class="col-md-12">
    <br />
    <h2 align="center">Loan Data</h2>
    <h4 ALIGN="center">(12% Yearly Nominal Rate)</h4>
  <br />
    <?php if($message = Session::get('success')): ?>
      <div class="alert alert-success">
      <p><?php echo e($message); ?></p>
  </div>
    <?php endif; ?>
  <div align="right">
   <a href="<?php echo e(route('loan.create')); ?>" class="btn btn-primary">Add New Loan</a>
   <br />
   <br />
  </div>
  <table class="table table-bordered table-striped">
   <tr>
    <th>Name</th>
    <th>Surname</th>
    <th>Car Model </th>
    <th>Car Price</th>
    <th>Number of Payments</th>
    <th>Advance</th>
    <th>Monthly Payment</th>
    <th></th>
   </tr>
   <?php $__currentLoopData = $loans; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
   <tr>
    <td><?php echo e($row['name']); ?></td>
    <td><?php echo e($row['surname']); ?></td>
    <td><?php echo e($row['carmodel']); ?></td>
    <td><?php echo e($row['price']); ?></td>
    <td><?php echo e($row['nper']); ?></td>
    <td><?php echo e($row['advance']); ?></td>
    <td><?php echo e($row['pmt']); ?> €</td>
    <td>
      <form method="post" class="delete_form" action="<?php echo e(action('LoanController@destroy', $row['id'])); ?>">
        <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="Delete" />
        <button type="submit" class="btn btn-danger">Delete</button>
     </form>
    </td>
    <td>
      
    </td>
   </tr>
   <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
  </table>
 </div>
</div>
<script>
  $(document).ready(function()
  {
    $(.'delete_form').on('submit', function()
    {
        if(confirm("Are you sure you want to delete the record?"))
        {
            return true;
        }
        else
        {
            return false;
        }
    });
  });
</script>
<?php $__env->stopSection(); ?>
  </body>
</html>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>