<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Compute your Basket Stats</title>
</head>
<body>
  
 

 
<?php $__env->startSection('content'); ?>
<div class="header-text">
 <h1>The Basket Stat Calculator <br/> Basketball Advance Statistics for Every Player</h1>
  <p>
  The only Greek Web App devoted to computing and analyzing Basketball Statistics (Basic & Advanced Level) for
  all players, regardless of age, level and league!
 </p>
  </div>
  <br/>
  <hr/>
  <div class="header-text">
    <h2>Fill the Stats form below to compute your League Game Statistics:</h2>
  </div>
  <hr/>
  <form class="form-inline" action="calculateStats" method="POST">
    <p>
      
      <label class="mr-sm-2" for="name">Name:</label>
      <input type="text" class="form-control mb-2 mr-sm-2" name="name" id="name" placeholder="Enter name">
      <label class="mr-sm-2" for="surname">Surname:</label>
      <input type="text" class="form-control mb-2 mr-sm-2" name="surname" id="surname" placeholder="Enter Surname">
      <label class="mr-sm-2" for="league">League:</label>
      <input type="text" class="form-control mb-2 mr-sm-2" name="league" id="league" placeholder="Enter League">
    </p>
    <section class="jumbotron">
    <div class="form-inline>">
      <p>
        <label for="points" class="mr-sm-2">Points:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="points" id="points"> <br/>
        <label for="games" class="mr-sm-2">Number of Games:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="games" id="games">
        <label for="minutes" class="mr-sm-2">Minutes Played:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="minutes" id="minutes">
      </p>
      <p>
        <label for="1pointattempt" class="mr-sm-2">1P Attempt:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="1pointattempt" id="1pointattempt">
        <label for="1pointmade" class="mr-sm-2">1P Made:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="1pointmade" id="1pointmade">
      </p>  
      <p>  
        <label for="2pointattempt" class="mr-sm-2">2P Attempt:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="2pointattempt" id="2pointattempt">
        <label for="2pointmade" class="mr-sm-2">2P Made:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="2pointmade" id="2pointmade">
      </p>
      <p>  
        <label for="3pointattempt" class="mr-sm-2">3P Attempt:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="3pointattempt" id="3pointattempt">
        <label for="3pointmade" class="mr-sm-2">3P Made:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="3pointmade" id="3pointmade">
      </p>   
    </div>
    </section>
    <p></p>
    <section class="jumbotron">
      <p>Rebounds</p>
        <label class="mr-sm-2" for="defensive">Defensive:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="defensive" id="defensive">
        <label class="mr-sm-2" for="offensive">Offensive:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="offensive" id="offensive">
    </section>
    <p></p>
     <section class="jumbotron">
      <p>Assists - Blocks - Turnovers</p>
        <label class="mr-sm-2" for="assists">Assists:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="assists" id="assists">
        <label class="mr-sm-2" for="blocks">Blocks:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="blocks" id="blocks">
        <label class="mr-sm-2" for="turnovers">Turnovers:</label>
        <input type="text" class="form-control mb-2 mr-sm-2" name="turnovers" id="turnovers">
    </section>
    <section class="jumbotron"></section>
    <button type="submit" class="btn btn-primary mb-2">Submit</button>
    </section>
  </form>
<div class="header-text">
 <p>
   
 </p>
  </div>
  
<?php $__env->stopSection(); ?>
  </body>
</html>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>