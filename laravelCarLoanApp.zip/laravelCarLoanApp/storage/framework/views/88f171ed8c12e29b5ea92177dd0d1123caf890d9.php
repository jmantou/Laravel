<!doctype html>
<html lang="en">
<head>
	<meta charset="UTF-8">
	<title>Compute the Loan of your next car</title>
</head>
<body>
  
 

 
<?php $__env->startSection('content'); ?>
<div class="header-text">
 <h1>The Car Loan Calculator <br/> Computing and Comparing Car Loans</h1>
  <p>
    The Car Loan calculator is a simple Laravel App for computing and comparing Car Loans. You can also save your computations
    in the apps database.
 </p>
  </div>
  <br/>
  <hr/>
  <div class="header-text">
    Based on the form information we calculate the following:
    <h3>Car Price: <?php echo e($_POST['price']); ?></h3>
    <h3>Advance: <?php echo e($_POST['advance']); ?></h3>
    <h3>Car Loan: <?php echo e($_POST['price'] - $_POST['advance']); ?></h3>
    <h3>Number of Monthly Payments: <?php echo e($_POST['nper']); ?></h3>
    <?php define ('RATE', 0.012) ?>
    <h3>PMT - Monthly Payment: 
        <?php echo e(round((($_POST['price'] - $_POST['advance']) * RATE) / (1 - (1 / pow((1 + RATE), $_POST['nper']))), 2)); ?> € 
    </h3>
  </div>
  <hr/>
 
<div class="header-text">
 <p>
   
 </p>
  </div>
  
<?php $__env->stopSection(); ?>
  </body>
</html>
<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>