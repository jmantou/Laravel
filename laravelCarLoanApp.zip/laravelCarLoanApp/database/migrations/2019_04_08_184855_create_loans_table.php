<?php

use Illuminate\Support\Facades\Schema;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Database\Migrations\Migration;

class CreateLoansTable extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('loans', function (Blueprint $table) {
            $table->increments('id');
            $table->string('name'); // MySql Varchar type
            $table->string('surname');
            $table->string('carmodel');
            $table->float('price'); // Maps to PV - Present Value in math type
            $table->float('advance');
            $table->integer('nper'); // Number of Payments
            $table->float('pmt'); // The Car monthly payment will eventually be a calculated field
            $table->timestamps();
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        Schema::dropIfExists('loans');
    }
}
